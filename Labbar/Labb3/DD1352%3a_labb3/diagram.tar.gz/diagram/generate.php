<?php

function makeNiceGraph($file, $newname, $removeCount)
{
	$lines = explode("\n", file_get_contents($file));

	for ($i = 0; $i < $removeCount; $i++)
	{
		array_shift($lines);
	}
	
	array_pop($lines);

	$fileContent = "digraph\n";
	$fileContent .= "{\n";

	foreach ($lines as $line)
	{
		$line = explode(" ", $line);
	
		$fileContent .= "\t" . $line[0] . ' -> ' . $line[1] . ' [label = ' . $line[2] . ']';
		$fileContent .= "\n";
	}

	$fileContent .= "}\n";

	file_put_contents($newname . '.dot', $fileContent);
	shell_exec('dot -Tpdf -o ' . $newname . '.pdf ' . $newname . '.dot');
}

makeNiceGraph('/home/m/p/mpola/adk16/labb3/testfall/flows/68.txt', 'indata', 3);
makeNiceGraph('/home/m/p/mpola/adk16/labb3/testfall/maxflows/68.txt', 'facit', 3);
makeNiceGraph('/home/m/p/mpola/out.txt', 'ours', 3);

?>
